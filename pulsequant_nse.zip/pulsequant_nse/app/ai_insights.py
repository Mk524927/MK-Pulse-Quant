import json
from typing import Dict, List
from google import genai


class GeminiInsightsEngine:
    def __init__(self, api_key: str, model: str = "gemini-2.5-flash"):
        self.api_key = api_key
        self.model = model
        self.client = genai.Client(api_key=api_key) if api_key else None

    def generate_insight(self, top10: List[Dict], risk_state: Dict, user_question: str = "") -> str:
        if not self.client:
            top_names = ", ".join(f"{c['name']} ({c['signal']}, Score {c['score']})" for c in top10[:3])
            return (
                f"Gemini API key not configured. Rule-based summary — Top 3: {top_names or 'Waiting for data'}. "
                f"Daily risk used: {risk_state['daily_loss_pct']:.2f}% / {risk_state['daily_risk_cap_pct']:.1f}%."
            )

        prompt = (
            "You are an institutional Indian F&O options portfolio manager. "
            "Analyze the live Top 10 scanned contracts and current risk state below, then provide concise, actionable feedback "
            "(market bias, top pick rationale, and 1% daily risk cap / 20% profit target status). "
            f"User question (if any): {user_question or 'Provide a live market & portfolio brief.'}\n\n"
            f"Risk State: {json.dumps(risk_state)}\n"
            f"Top 10 F&O Options: {json.dumps(top10)}"
        )
        try:
            resp = self.client.models.generate_content(model=self.model, contents=prompt)
            return resp.text or "No insight returned."
        except Exception as exc:
            return f"Gemini insight error: {exc}"
