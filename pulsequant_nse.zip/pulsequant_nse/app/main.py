import asyncio
from contextlib import asynccontextmanager
from typing import Dict, List
from fastapi import FastAPI
from fastapi.responses import FileResponse
from pydantic import BaseModel

from app.ai_insights import GeminiInsightsEngine
from app.analyzer import score_contracts
from app.config import settings
from app.nse_client import NSEOptionChainClient
from app.risk_engine import RiskEngine

nse = NSEOptionChainClient()
ai_engine = GeminiInsightsEngine(settings.gemini_api_key, settings.gemini_model)
risk_engine = RiskEngine(
    settings.capital_inr,
    settings.daily_risk_cap_pct,
    settings.stop_loss_pct,
    settings.profit_target_pct,
)

state: Dict = {
    "top10": [],
    "price_map": {},
    "history_map": {},
    "approved_keys": set(),
    "auto_trade": False,
    "last_insight": "Connecting to NSE India Option Chain and Gemini AI insights...",
    "feed_status": "INITIALIZING_NSE",
}


class AskRequest(BaseModel):
    question: str


async def market_loop():
    symbols = [s.strip().upper() for s in settings.nse_symbols.split(",") if s.strip()]
    tick = 0
    while True:
        try:
            all_contracts: List[Dict] = []
            for sym in symbols:
                all_contracts.extend(await nse.fetch_option_chain(sym))

            if all_contracts:
                state["feed_status"] = "LIVE_NSE_FEED"
                for c in all_contracts:
                    state["price_map"][c["key"]] = c["ltp"]
                state["top10"] = score_contracts(
                    all_contracts,
                    state["history_map"],
                    settings.stop_loss_pct,
                    settings.profit_target_pct,
                )
                risk_engine.check_exits_and_kill_switch(state["price_map"])

                if tick % 4 == 0:
                    risk_snap = {
                        "equity": round(risk_engine.total_equity(state["price_map"]), 2),
                        "daily_loss_pct": round(risk_engine.daily_loss_pct(state["price_map"]), 2),
                        "daily_risk_cap_pct": settings.daily_risk_cap_pct,
                        "open_positions": len(risk_engine.positions),
                        "kill_switch": risk_engine.kill_switch_triggered,
                    }
                    state["last_insight"] = ai_engine.generate_insight(state["top10"], risk_snap)
            tick += 1
        except Exception as exc:
            state["feed_status"] = f"NSE_ERROR: {exc}"
        await asyncio.sleep(settings.poll_interval_sec)


@asynccontextmanager
async def lifespan(app: FastAPI):
    task = asyncio.create_task(market_loop())
    yield
    task.cancel()


app = FastAPI(title="PulseQuant Live NSE F&O AI Platform", lifespan=lifespan)


@app.get("/")
async def index():
    return FileResponse("static/index.html")


@app.get("/api/state")
async def get_state():
    return {
        "feed_status": state["feed_status"],
        "paper_mode": settings.paper_mode,
        "auto_trade": state["auto_trade"],
        "approved_keys": list(state["approved_keys"]),
        "top10": state["top10"],
        "positions": risk_engine.positions,
        "history": risk_engine.history[:30],
        "equity": round(risk_engine.total_equity(state["price_map"]), 2),
        "cash": round(risk_engine.cash, 2),
        "daily_loss_pct": round(risk_engine.daily_loss_pct(state["price_map"]), 2),
        "daily_risk_cap_pct": settings.daily_risk_cap_pct,
        "profit_target_pct": settings.profit_target_pct,
        "kill_switch": risk_engine.kill_switch_triggered,
        "last_insight": state["last_insight"],
    }


@app.post("/api/approve/{contract_key}")
async def approve_contract(contract_key: str):
    if risk_engine.kill_switch_triggered:
        return {"ok": False, "error": "Daily 1% risk cap kill-switch is active."}
    state["approved_keys"].add(contract_key)
    state["auto_trade"] = True
    match = next((c for c in state["top10"] if c["key"] == contract_key), None)
    if match and not any(p["key"] == contract_key for p in risk_engine.positions):
        alloc = risk_engine.total_equity(state["price_map"]) * (settings.allocation_per_trade_pct / 100.0)
        qty = max(1, int(alloc // match["ltp"]))
        side = "SHORT" if match["action"] == "SELL" else "LONG"
        risk_engine.cash -= qty * match["ltp"]
        risk_engine.positions.append({
            "key": contract_key,
            "name": match["name"],
            "side": side,
            "qty": qty,
            "entry_price": match["ltp"],
            "sl": match["stop_loss"],
            "tp": match["target_price"],
        })
    return {"ok": True, "approved_keys": list(state["approved_keys"])}


@app.post("/api/ai/ask")
async def ask_ai(req: AskRequest):
    risk_snap = {
        "equity": round(risk_engine.total_equity(state["price_map"]), 2),
        "daily_loss_pct": round(risk_engine.daily_loss_pct(state["price_map"]), 2),
        "daily_risk_cap_pct": settings.daily_risk_cap_pct,
        "open_positions": len(risk_engine.positions),
        "kill_switch": risk_engine.kill_switch_triggered,
    }
    answer = ai_engine.generate_insight(state["top10"], risk_snap, req.question)
    state["last_insight"] = answer
    return {"insight": answer}


@app.post("/api/nse-insights")
async def get_nse_insights():
    symbols = [s.strip().upper() for s in settings.nse_symbols.split(",") if s.strip()]
    all_contracts: List[Dict] = []
    for sym in symbols:
        all_contracts.extend(await nse.fetch_option_chain(sym))
    if all_contracts:
        state["feed_status"] = "LIVE_NSE_FEED"
        for c in all_contracts:
            state["price_map"][c["key"]] = c["ltp"]
        state["top10"] = score_contracts(
            all_contracts,
            state["history_map"],
            settings.stop_loss_pct,
            settings.profit_target_pct,
        )
    risk_snap = {
        "equity": round(risk_engine.total_equity(state["price_map"]), 2),
        "daily_loss_pct": round(risk_engine.daily_loss_pct(state["price_map"]), 2),
        "daily_risk_cap_pct": settings.daily_risk_cap_pct,
        "open_positions": len(risk_engine.positions),
        "kill_switch": risk_engine.kill_switch_triggered,
    }
    state["last_insight"] = ai_engine.generate_insight(state["top10"], risk_snap)
    return {"top10": state["top10"], "insight": state["last_insight"], "feed_status": state["feed_status"]}
