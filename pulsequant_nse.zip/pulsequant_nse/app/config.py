from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    nse_symbols: str = "NIFTY,BANKNIFTY,FINNIFTY"

    gemini_api_key: str = ""
    gemini_model: str = "gemini-2.5-flash"

    capital_inr: float = 1_000_000.0
    allocation_per_trade_pct: float = 20.0
    stop_loss_pct: float = 1.0
    profit_target_pct: float = 20.0
    daily_risk_cap_pct: float = 1.0

    paper_mode: bool = True
    poll_interval_sec: int = 10


settings = Settings()
