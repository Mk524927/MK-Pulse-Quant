from typing import Dict, List


class RiskEngine:
    def __init__(self, initial_capital: float, daily_risk_cap_pct: float, stop_loss_pct: float, profit_target_pct: float):
        self.initial_capital = initial_capital
        self.cash = initial_capital
        self.daily_risk_cap_pct = daily_risk_cap_pct
        self.stop_loss_pct = stop_loss_pct
        self.profit_target_pct = profit_target_pct
        self.kill_switch_triggered = False
        self.positions: List[Dict] = []
        self.history: List[Dict] = []

    def total_equity(self, price_map: Dict[str, float]) -> float:
        unrealized = 0.0
        locked = 0.0
        for pos in self.positions:
            cur = price_map.get(pos["key"], pos["entry_price"])
            direction = 1 if pos["side"] == "LONG" else -1
            unrealized += (cur - pos["entry_price"]) * pos["qty"] * direction
            locked += pos["entry_price"] * pos["qty"]
        return self.cash + locked + unrealized

    def daily_loss_pct(self, price_map: Dict[str, float]) -> float:
        eq = self.total_equity(price_map)
        return max(0.0, ((self.initial_capital - eq) / self.initial_capital) * 100.0)

    def check_exits_and_kill_switch(self, price_map: Dict[str, float]) -> List[Dict]:
        closed_events = []
        for pos in list(self.positions):
            cur = price_map.get(pos["key"], pos["entry_price"])
            hit = None
            if pos["side"] == "LONG":
                if cur <= pos["sl"]:
                    hit = "Stop-Loss Hit"
                elif cur >= pos["tp"]:
                    hit = "20% Profit Target Hit"
            else:
                if cur >= pos["sl"]:
                    hit = "Stop-Loss Hit"
                elif cur <= pos["tp"]:
                    hit = "20% Profit Target Hit"
            if hit:
                closed_events.append(self.close_position(pos, cur, hit))

        if self.daily_loss_pct(price_map) >= self.daily_risk_cap_pct:
            self.kill_switch_triggered = True
            for pos in list(self.positions):
                cur = price_map.get(pos["key"], pos["entry_price"])
                closed_events.append(self.close_position(pos, cur, "1% Daily Risk Cap Kill-Switch"))
        return closed_events

    def close_position(self, pos: Dict, exit_price: float, reason: str) -> Dict:
        direction = 1 if pos["side"] == "LONG" else -1
        pnl = (exit_price - pos["entry_price"]) * pos["qty"] * direction
        self.cash += pos["entry_price"] * pos["qty"] + pnl
        self.positions.remove(pos)
        record = {**pos, "exit_price": exit_price, "pnl": round(pnl, 2), "reason": reason}
        self.history.insert(0, record)
        return record
