from typing import Any, Dict, List
import httpx


class NSEOptionChainClient:
    BASE_URL = "https://www.nseindia.com"
    HEADERS = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "en-US,en;q=0.9",
        "Referer": "https://www.nseindia.com/option-chain",
    }

    def __init__(self):
        self._client = httpx.AsyncClient(headers=self.HEADERS, timeout=15.0, follow_redirects=True)
        self._cookies_ready = False

    async def _ensure_cookies(self):
        if not self._cookies_ready:
            await self._client.get(f"{self.BASE_URL}/option-chain")
            self._cookies_ready = True

    async def fetch_option_chain(self, symbol: str) -> List[Dict[str, Any]]:
        await self._ensure_cookies()
        url = f"{self.BASE_URL}/api/option-chain-indices"
        resp = await self._client.get(url, params={"symbol": symbol})
        if resp.status_code in (401, 403):
            self._cookies_ready = False
            await self._ensure_cookies()
            resp = await self._client.get(url, params={"symbol": symbol})
        resp.raise_for_status()

        payload = resp.json()
        records = payload.get("records", {})
        underlying = float(records.get("underlyingValue") or 0)
        rows = records.get("data", [])

        contracts: List[Dict[str, Any]] = []
        for row in rows:
            strike = round(float(row.get("strikePrice") or 0))
            if strike <= 0:
                continue
            # Focus on strikes within +/- 4% of spot for liquid ATM/near-OTM options
            if underlying > 0 and abs(strike - underlying) / underlying > 0.04:
                continue

            for opt_type in ("CE", "PE"):
                leg = row.get(opt_type)
                if not isinstance(leg, dict):
                    continue
                ltp = float(leg.get("lastPrice") or 0)
                if ltp <= 0:
                    continue
                contracts.append({
                    "key": f"{symbol}_{strike}_{opt_type}",
                    "name": f"{symbol} {strike} {opt_type}",
                    "symbol": symbol,
                    "strike": strike,
                    "type": opt_type,
                    "ltp": round(ltp, 2),
                    "iv": float(leg.get("impliedVolatility") or 0),
                    "oi": float(leg.get("openInterest") or 0),
                    "oi_change": float(leg.get("pchangeinOpenInterest") or 0),
                    "underlying": underlying,
                })
        return contracts
