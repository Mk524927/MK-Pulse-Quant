from typing import Dict, List


def calc_ema(series: List[float], period: int) -> List[float]:
    if not series:
        return []
    k = 2.0 / (period + 1)
    out = [series[0]]
    for p in series[1:]:
        out.append(p * k + out[-1] * (1.0 - k))
    return out


def calc_rsi(series: List[float], period: int = 14) -> float:
    if len(series) < period + 1:
        return 50.0
    gains, losses = 0.0, 0.0
    for i in range(len(series) - period, len(series)):
        diff = series[i] - series[i - 1]
        if diff >= 0:
            gains += diff
        else:
            losses += abs(diff)
    avg_gain = gains / period
    avg_loss = losses / period
    if avg_loss == 0:
        return 50.0 if avg_gain == 0 else 100.0
    rs = avg_gain / avg_loss
    return round(100.0 - (100.0 / (1.0 + rs)), 2)


def score_contracts(
    contracts: List[Dict],
    history_map: Dict[str, List[float]],
    stop_loss_pct: float = 1.0,
    profit_target_pct: float = 20.0,
) -> List[Dict]:
    ranked = []
    for c in contracts:
        key = c["key"]
        prices = history_map.setdefault(key, [])
        ltp = c["ltp"]
        prices.append(ltp)
        if len(prices) > 80:
            prices.pop(0)

        ema9 = calc_ema(prices, 9)[-1] if prices else ltp
        ema21 = calc_ema(prices, 21)[-1] if prices else ltp
        rsi = calc_rsi(prices, 14)
        spread_pct = ((ema9 - ema21) / ema21 * 100.0) if ema21 else 0.0
        oi_chg = float(c.get("oi_change", 0))

        is_buy = (spread_pct >= 0 and rsi < 70) or rsi < 35
        action = "BUY" if is_buy else "SELL"

        if action == "BUY":
            entry_trigger = round(max(ltp * 1.002, ema9), 2)
            sl_trigger = round(entry_trigger * (1.0 - stop_loss_pct / 100.0), 2)
            tp_trigger = round(entry_trigger * (1.0 + profit_target_pct / 100.0), 2)
            trigger_reason = f"Buy >= ₹{entry_trigger:.2f} (EMA9 ₹{ema9:.2f}, RSI {rsi}, OI {oi_chg:+.1f}%)"
        else:
            entry_trigger = round(min(ltp * 0.998, ema9), 2)
            sl_trigger = round(entry_trigger * (1.0 + stop_loss_pct / 100.0), 2)
            tp_trigger = round(entry_trigger * (1.0 - profit_target_pct / 100.0), 2)
            trigger_reason = f"Sell <= ₹{entry_trigger:.2f} (EMA9 ₹{ema9:.2f}, RSI {rsi}, OI {oi_chg:+.1f}%)"

        score = min(
            99,
            max(
                35,
                round(45 + abs(spread_pct) * 15 + min(25, abs(oi_chg) * 0.8) + (15 if rsi < 35 or rsi > 65 else 5)),
            ),
        )

        ranked.append({
            **c,
            "rsi": rsi,
            "ema9": round(ema9, 2),
            "ema21": round(ema21, 2),
            "action": action,
            "signal": action,
            "entry_trigger": entry_trigger,
            "stop_loss": sl_trigger,
            "target_price": tp_trigger,
            "trigger_reason": trigger_reason,
            "score": score,
        })

    ranked.sort(key=lambda x: x["score"], reverse=True)
    return ranked[:10]
