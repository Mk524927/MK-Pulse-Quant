# PulseQuant — Live NSE Option Chain + Gemini AI Platform

Fetches live F&O Option Chain data directly from NSE India (`nseindia.com/api/option-chain-indices`), ranks the Top 10 Buy/Sell option suggestions with exact Entry, 1% Stop-Loss, and 20% Profit-Target triggers, and generates real-time market insights using the Gemini API.

## Setup & Run
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Copy `.env.example` to `.env` and add your `GEMINI_API_KEY` (from [Google AI Studio](https://aistudio.google.com/apikey)).
3. Start the server:
   ```bash
   uvicorn app.main:app --host 0.0.0.0 --port 8000
   ```
4. Open `http://localhost:8000` in your browser.
